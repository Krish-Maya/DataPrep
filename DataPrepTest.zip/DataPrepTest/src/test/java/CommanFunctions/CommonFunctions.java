package CommanFunctions;

public class CommonFunctions {

}
