package DataPrep.DataPrep;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class GridTest {

	public static void main(String[] args) throws MalformedURLException, InterruptedException{
		// TODO Auto-generated method stub
		
		String url="https://google.com";
		//String Node="http://10.59.7.233:5555/wd/hub";
		RemoteWebDriver driver = null;
		driver=new RemoteWebDriver(new URL("http://localhost:5555/wd/hub"), getChromeOptions());
		Thread.sleep(3000);
		driver.navigate().to(url);
		driver.quit();
		

	}
	public static ChromeOptions getChromeOptions() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--disable-popup-blocking");
        //options.addArguments("--incognito");
        return options;
    }

}
